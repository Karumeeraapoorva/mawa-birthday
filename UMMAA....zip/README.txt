HOW TO USE

1. Open index.html in a browser to preview the birthday page.
2. To publish it free with GitHub Pages:
   - Create a GitHub repository.
   - Upload index.html.
   - Open Settings -> Pages.
   - Select Deploy from branch -> main -> /root -> Save.
   - GitHub will give you the website link.
3. Send that link to Mawa on his birthday.

No music is included.
